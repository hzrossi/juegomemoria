//: Playground - noun: a place where people can play

import UIKit

//declaração array
var array:[Int] = []

//preenchendo array
for i in 0...100 {
	array.insert(i, atIndex: i)
}

//percorrendo array
for i in 0...array.count-1 {
	//imprimindo divisíveis por 5
	if (array[i] % 5 == 0) {
		print("\(array[i]) - Bingo!!!")
	}
	//imprimindo divisíveis por 2 (pares)
	if (array[i] % 2 == 0) {
		print("\(array[i]) - Par!!!")
	}
	//imprimindo não divisíveis por 2 (ímpares)
	if (array[i] % 2 != 0) {
		print("\(array[i]) - Impar!!!")
	}
	//imprimindo entre 30 e 40
	if (array[i] >= 30 && array[i] <= 40) {
		print("\(array[i]) - Viva swift!!!")
	}
}